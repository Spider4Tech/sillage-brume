# Synthèse de la campagne lourde BRUME

## Paramètres

- Quartets par combinaison : 2^20
- Combinaisons par tour : 32
- Graines : 0xB00, 0xB01, 0xB02, 0xB03, 0xB04 (5)
- Taille de famille Bonferroni : 15
- Seuils statistiques par run : 5.998881 à 5.998881
- Nombre de lignes CSV attendu par run : 32768

## Audit

- Métadonnées cohérentes : True
- CSV complets : True
- Géométrie des entrées identique entre candidates pour chaque graine : True

## Boomerang C : scores Z par profondeur

Le tableau donne la moyenne et la médiane des maxima Z sur les graines. La colonne `significatif` compte les graines dépassant le seuil corrigé de chaque campagne.

| Candidate | Tours | Z moyen | Z médian | Z min–max | Graines significatives | Retours exacts moyens |
|---|---:|---:|---:|---:|---:|---:|
| BRUME | 1 | 3965.935 | 3965.935 | 3965.935–3965.935 | 5/5 | 33135001.6 |
| BRUME | 2 | 3965.935 | 3965.935 | 3965.935–3965.935 | 5/5 | 5662160.0 |
| BRUME | 3 | 16.310 | 13.717 | 6.439–31.262 | 5/5 | 2.2 |
| BRUME | 4 | 4.171 | 3.917 | 3.667–4.914 | 0/5 | 0.0 |
| BRUME | 5 | 3.904 | 3.970 | 3.425–4.184 | 0/5 | 0.0 |
| BRUME | 6 | 3.775 | 3.720 | 3.385–4.107 | 0/5 | 0.0 |
| BRUME | 7 | 3.663 | 3.623 | 3.494–3.966 | 0/5 | 0.0 |
| BRUME | 8 | 3.808 | 3.784 | 3.429–4.163 | 0/5 | 0.0 |
| SBOX6 | 1 | 3965.935 | 3965.935 | 3965.935–3965.935 | 5/5 | 33187479.6 |
| SBOX6 | 2 | 3965.935 | 3965.935 | 3965.935–3965.935 | 5/5 | 5678400.8 |
| SBOX6 | 3 | 15.108 | 12.317 | 5.797–27.768 | 4/5 | 5.6 |
| SBOX6 | 4 | 3.944 | 4.002 | 3.272–4.571 | 0/5 | 0.0 |
| SBOX6 | 5 | 3.773 | 3.905 | 3.292–4.115 | 0/5 | 0.0 |
| SBOX6 | 6 | 3.713 | 3.865 | 3.280–4.087 | 0/5 | 0.0 |
| SBOX6 | 7 | 3.917 | 3.687 | 3.369–4.765 | 0/5 | 0.0 |
| SBOX6 | 8 | 4.125 | 3.994 | 3.829–4.478 | 0/5 | 0.0 |
| SBOX_V3 | 1 | 3965.935 | 3965.935 | 3965.935–3965.935 | 5/5 | 33187234.4 |
| SBOX_V3 | 2 | 3965.935 | 3965.935 | 3965.935–3965.935 | 5/5 | 5879308.4 |
| SBOX_V3 | 3 | 14.717 | 12.805 | 10.409–24.214 | 5/5 | 1.6 |
| SBOX_V3 | 4 | 3.827 | 3.917 | 3.578–3.990 | 0/5 | 0.0 |
| SBOX_V3 | 5 | 3.741 | 3.772 | 3.401–4.067 | 0/5 | 0.0 |
| SBOX_V3 | 6 | 3.844 | 3.522 | 3.413–4.894 | 0/5 | 0.0 |
| SBOX_V3 | 7 | 3.753 | 3.812 | 3.260–4.232 | 0/5 | 0.0 |
| SBOX_V3 | 8 | 3.834 | 3.829 | 3.429–4.188 | 0/5 | 0.0 |

## Trails multi-tours

Les coûts ci-dessous sont des coûts de caractéristiques heuristiques en demi-bits. Le switch boomerang a été recalculé avec `2*log2(16/BCT)` en flottant, sans arrondi intermédiaire.

| Candidate | DDT max | Lignes DDT max 2 | BCT max | Lignes BCT max 2 | DBCT max | Coût diff. à l'horizon (demi-bits) | Coût lin. à l'horizon (demi-bits) | Switch boomerang 14 tours (demi-bits) |
|---|---:|---|---:|---|---:|---:|---:|---:|
| BRUME | 4 | [1, 2, 9] | 10 | [1, 2, 9] | 52 | 5660 | 2834 | 5580.61080685 |
| SBOX6 | 4 | [] | 6 | [] | 32 | 5200 | 2842 | 5071.608999827 |
| SBOX_V3 | 4 | [3, 4, 5, 12, 14] | 8 | [3, 4, 5, 12, 14] | 32 | 6042 | 2834 | 5911.882699948 |

## Lecture

Ne pas classer les S-boxes à partir du seul BCT maximal ou d'un seul `z_max`. SBOX6 a BCT max 6, mais le profil des lignes DDT/BCT et les meilleures pistes multi-tours peuvent être moins favorables que ceux de SBOX_V3. Les résultats de pistes restent heuristiques.

Les tests C explorent uniquement les profondeurs codées dans le banc (`RB`, actuellement 8 tours). Ils ne démontrent pas la sécurité de la permutation à 32 tours.
